<script setup lang="ts">
import { useAppCrudStore } from '../store/AppCrudStore';
const appCrudStore = useAppCrudStore()
const isDeleteModalOpen = computed({
    get: () => appCrudStore.isDeleteModalOpen,
    set: (value) => appCrudStore.isDeleteModalOpen = value
})

const isLoading = ref(false)

const deleteItem = async () => {
    try {
        isLoading.value = true
        console.log('test');
        if (appCrudStore.deleteService)
            await appCrudStore.deleteService(appCrudStore.itemId as string)
        else
            throw new Error("No delete service provided")
    } catch (e) {
        console.log(e);
    } finally {
        isLoading.value = false
        isDeleteModalOpen.value = false;
    }
}
</script>
<template>
    <AppDialog size="sm" title="Delete Confirmation" v-model="isDeleteModalOpen" :loading="isLoading">
        Are you sure you want to delete this item?
        <template #actions>
            <BaseButton @click="deleteItem" color="primary">
                <Icon name="ph:trash" />
                Delete
            </BaseButton>
        </template>
    </AppDialog>
</template>
