import { AppClient } from "~/services/app-client";

interface IAppCrudServices {
}
export class AppCrudServices implements IAppCrudServices {
}
