interface AppFiltersProps<T> {
    filters: T
    query?: boolean
}