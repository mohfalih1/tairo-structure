<script setup lang="ts" generic="T">
import type { RouteParamsRaw } from 'vue-router';


interface Props {
    filters: AppFiltersProps<T>
}
const props = defineProps<Props>()
const router = useRouter()
const route = useRoute()
const filters = computed(() => props.filters)
watch(filters, () => {
    const newParams: Record<string, string> = {}
    const routeQuery: Record<string, string> = {}
    Object.keys(route.query).forEach(queryKey => {
        if (!Object.keys(filters.value).includes(queryKey)) {
            routeQuery[queryKey] = route.query[queryKey]
        }
    })
    Object.keys(filters.value).forEach((key: string) => {
        if (filters.value[key as keyof typeof filters.value]) {
            newParams[key] = filters.value[key as keyof typeof filters.value] as string
        }
    })

    console.log(newParams, routeQuery);

    router.push({
        ...route,
        query: {
            ...routeQuery,
            ...newParams
        }
    })
}, {
    deep: true
})
</script>
<template>
    <slot></slot>
</template>