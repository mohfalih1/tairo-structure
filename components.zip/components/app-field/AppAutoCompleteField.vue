<script lang="ts" setup generic="T">
import axiosInstance from '~/services/app-client/axios.js'
import { watchDebounced, onClickOutside } from '@vueuse/core';
interface Props {
  items?: T[]
  itemLabel?: string
  itemValue?: string
  label?: string
  appendIcon?: string
  getUrl?: string
  fetchOnSearch?: boolean
  searchKey?: string
  modelValue: string | number | null
}

const props = defineProps<Props>()

defineSlots<
  {
    item: { item: T }
  }
>()
const menu = ref<{ query: string } | null>(null)
const emit = defineEmits<{
  (e: 'update:modelValue', value: string | number | null): void
  (e: 'update:objectValue', value: T | null): void
}>()

const selectedItem = ref<T>()
const modelValue = computed({
  get: () => props.modelValue,
  set: () => {
    emit('update:modelValue', itemWithValue(selectedItem.value!))
    emit('update:objectValue', selectedItem.value!)
  }
})
watch(selectedItem, () => {
  modelValue.value = selectedItem.value!

})
const search = computed(() => {
  if (menu.value)
    return menu.value!.query
  return ''
})
const items = ref<T[]>(props.items || [])
const searchKey = computed(() => props.searchKey || 'text')
function itemWithLabel(item: T): string {
  if (!item) return ''
  if (typeof item === 'string')
    return item
  return item[props.itemLabel! as keyof T] as string
}
function itemWithValue(item: T): string | null {
  if (!item) return null
  if (typeof item === 'string')
    return item
  return item[props.itemValue! as keyof T] as string
}
const filteredItems = computed(() => {
  if (!props.fetchOnSearch)
    return items.value.filter(item => itemWithLabel(item as T).toLowerCase().includes(search.value.toLowerCase()))
  return items.value
})
async function fetchData() {
  if (props.getUrl) {
    let params = {}
    if (props.fetchOnSearch)
      params = { [searchKey.value]: search.value }

    const res = await axiosInstance.get(props.getUrl, { params })
    items.value = res.data.result.data
  }
}

onMounted(() => {
  if (props.getUrl)
    fetchData()
})

const slots = useSlots()
const hasSlot = (name: string) => !!slots[name]

watch(
  search,
  () => {
    if (props.fetchOnSearch)
      fetchData()
  },
)
</script>

<template>
  <div relative>
    <BaseAutocomplete clearable dropdown ref="menu" :display-value="itemWithLabel" v-model="selectedItem"
      :items="filteredItems" :label="label">
      <template #item="{ item, active }">
        <p class="p-1" v-if="!hasSlot('item')" :class="{
          'bg-brand-primary': active,
        }">
          {{ itemWithLabel(item as T) }}
        </p>

        <slot v-else name="item" :item="item" />
      </template>
    </BaseAutocomplete>
  </div>
</template>
