<script setup lang="ts">
const props = defineProps<{
  label?:string
  size?: 'sm'|'md'|'lg'
  type?: 'text'|'number'|'email'|'password'
}>()
const model = defineModel()
</script>
<template>
  <BaseInput 
    :size="props.size ?? 'md'"
    :label="props.label"
    :placeholder="props.label"
    :type="props.type ?? 'text'"
    v-model="model"
  />
</template>
