<template>
    <TairoTableRow :hoverable="false">
        <TairoTableCell colspan="100">
            <AppNoData />
        </TairoTableCell>
    </TairoTableRow>
</template>