<template>
  <BaseThemeToggle />
</template>
