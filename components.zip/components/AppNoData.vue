<template>
    <BasePlaceholderPage title="No Data Found" subtitle="No data found, please try again later"> </BasePlaceholderPage>

</template>